<?php
 
return [
    'channel' => env('PUSHER_CHANNEL',''),
    'pusher_id' => env('PUSHER_APP_ID',''),
    'pusher_key' => env('PUSHER_APP_KEY',''),
    'pusher_cluster' => env('PUSHER_APP_CLUSTER',''),
];