

<?php $__env->startSection('content'); ?>

            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Datatable</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Datatable</li>
                            </ol>
                            <a href="<?php echo e(route('member.create')); ?>" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Create New</a>

                        </div>
                    </div>
                </div>
                <form action="<?php echo e(route('member.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                   <div class="row justify-content-center">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Tambah Data Baru</h4>
                                <h6 class="card-subtitle"> Peserta Munas APJATI 2020</h6>
                                <div class="form-group">
                                  <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nama" required name="nama" autocomplete="off" value="<?php echo e(old('nama')); ?>">
                                </div>
                                <div class="form-group">
                                    <select class="select2 form-control custom-select" name="company_id style="width: 100%; height:36px;">
                                        <option label="Pacific Time Zone">
                                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option required value="<?php echo e($company->id); ?>"><?php echo e($company->nama); ?></option>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <input type="number" class="form-control" id="input-1" autocomplete="off" placeholder="Masukkan Nomor Ponsel" required name="no_hp" value="<?php echo e(old('no_hp')); ?>">
                                </div>
                                <div class="form-group"> <input type="file" id="input-file-now" class="dropify" name="photo" /></div>
                                

                                <div class="form-group">
                                    <div class="form-group">
                                          <button type="submit" class="btn btn-primary icheck-material-primary"> 
                                            <input id="primary1" type="radio" name="kehadiran" value="tidak_hadir" checked="tidak_hadir" style="opacity: 0%">
                                            Simpan
                                            <input id="primary1" type="radio" name="kehadiran" style="opacity: 0%">

                                          </button>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
                
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/member/create.blade.php ENDPATH**/ ?>