

<?php $__env->startSection('content'); ?>

            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Datatable</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Datatable</li>
                            </ol>

                        </div>
                    </div>
                </div>
                <form action="<?php echo e(route('member.update', $member->uuid)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                   <div class="row justify-content-center">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Ubah Data Baru</h4>
                                <h6 class="card-subtitle"> Peserta Munas APJATI 2020</h6>
                                <div class="form-group">
                                    <img class="row justify-content-center" src="<?php echo e(asset($member->photo)); ?>" style="display: block;
    margin-left: auto;
    margin-right: auto;">
                                    <br>
                                    <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nama" required name="nama" autocomplete="off" value="<?php echo e($member->nama); ?>">
                                </div>
                                <div class="form-group">
                                    <select class="select2 form-control custom-select" name="company_id" style="width: 100%; height:36px;">
                                          <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=" <?php echo e($company->id); ?>"
                                            <?php if($company->id == $member->company_id): ?>
                                                selected
                                            <?php endif; ?>><?php echo e($company->nama); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        </option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <input type="number" class="form-control" id="input-1" autocomplete="off" placeholder="Masukkan Nomor Ponsel" required name="no_hp" value="<?php echo e($member->no_hp); ?>">
                                </div>
                                <div class="form-group"> <input type="file" id="input-file-now" class="dropify" name="photo" /></div>
                                

                                <div class="form-group">
                                    <div class="form-group">
                                          <button type="submit" class="btn btn-primary icheck-material-primary"> 
                                            <input id="primary1" type="radio" name="kehadiran" value="tidak_hadir" checked="tidak_hadir" style="opacity: 0%">
                                            Simpan
                                            <input id="primary1" type="radio" name="kehadiran" style="opacity: 0%">

                                          </button>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
                
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/member/edit.blade.php ENDPATH**/ ?>