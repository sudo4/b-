<?php $__env->startSection('content'); ?>
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Datatable</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Datatable</li>
                            </ol>
                            <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content bg-secondary">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                                  <form method="post" action="<?php echo e(route('users.store')); ?>" data-parsley-validate class="form-horizontal form-label-left">
                                                      <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?> row">
                                                          <label for="name" class="col-sm-2 col-form-label">Name</label>
                                                          <div class="col-sm-10">
                                                              <input type="text" value="<?php echo e(Request::old('name') ?: ''); ?>" id="name" name="name" class="form-control col-md-11 col-xs-12"> <?php if($errors->has('name')): ?>
                                                              <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>

                                                      <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> row">
                                                          <label for="email" class="col-sm-2 col-form-label">Email</label>
                                                          <div class="col-sm-10">
                                                              <input type="text" value="<?php echo e(Request::old('email') ?: ''); ?>" id="email" name="email" class="form-control col-md-11 col-xs-12"> <?php if($errors->has('email')): ?>
                                                              <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>

                                                      <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> row">
                                                          <label for="password" class="col-sm-2 col-form-label">Password</label>
                                                          <div class="col-sm-10">
                                                              <input type="password" value="<?php echo e(Request::old('password') ?: ''); ?>" id="password" name="password" class="form-control col-md-11 col-xs-12"> <?php if($errors->has('password')): ?>
                                                              <span class="help-block"><?php echo e($errors->first('password')); ?></span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>

                                                      <div class="form-group<?php echo e($errors->has('confirm_password') ? ' has-error' : ''); ?> row">
                                                          <label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
                                                          <div class="col-sm-10">
                                                              <input type="password" value="<?php echo e(Request::old('confirm_password') ?: ''); ?>" id="confirm_password" name="confirm_password"
                                                                  class="form-control col-md-11 col-xs-12"> <?php if($errors->has('confirm_password')): ?>
                                                              <span class="help-block"><?php echo e($errors->first('confirm_password')); ?></span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>

                                                      <div class="form-group<?php echo e($errors->has('role_id') ? ' has-error' : ''); ?> row">
                                                          <label class="col-sm-2 col-form-label" for="category_id">Role
                                                              <span class="required">*</span>
                                                          </label>
                                                          <div class="col-sm-10">
                                                              <select class="form-control col-md-11" id="role_id" name="role_id">
                                                                  <?php if(count($roles)): ?> <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                  <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                                                              </select>
                                                              <?php if($errors->has('role_id')): ?>
                                                              <span class="help-block"><?php echo e($errors->first('role_id')); ?></span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>

                                                      <div class="ln_solid"></div>

                                                      <div class="form-group">
                                                          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                              <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                                                              <button type="submit" class="btn btn-success">Create User</button>
                                                          </div>
                                                      </div>
                                                  </form>
                                            </div>
                                            
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->

                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Export</h4>
                                <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                         <thead>
                                            <tr>
                                              <th>Username</th>
                                              <th>Email</th>
                                              <th>Role</th>
                                              <?php if (app('laratrust')->hasRole('superadministrator')) : ?>
                                              <th>Action</th>
                                              <?php endif; // app('laratrust')->hasRole ?>
                                            </tr>
                                          </thead>
                                          <tbody>
                                              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                    <td><?php echo e($user->name); ?></td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td>
                                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($r->display_name); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                     <?php if (app('laratrust')->hasRole('superadministrator')) : ?>
                                                    <td class="text-center">
                                                        <a type="button" class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                                                            <span class="caret"></span>
                                                        </a>
                                                        <div class="dropdown-menu">
                                                         
                                                          <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="dropdown-item">Edit</a>
                                                          <?php endif; // app('laratrust')->hasRole ?>
                                                          <a href="<?php echo e(route('users.show', $user->id)); ?>" class="dropdown-item">Delete</a>
                                                        </div>
                                                    </td>
                                                  </tr>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/admin/users/users_list.blade.php ENDPATH**/ ?>