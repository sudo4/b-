<!DOCTYPE html>
<html>
<head>
    <title>Page not found</title>
</head>
<body>
    <p>404 Page not found</p>
</body>
</html><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/errors/404.blade.php ENDPATH**/ ?>