

<?php $__env->startSection('content'); ?>
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Datatable</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Datatable</li>
                            </ol>
                            <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content bg-secondary">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('company.store')); ?>", method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                      <label for="input-1">Nama p3mi</label>
                                                      <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nama" required name="nama" value="<?php echo e(old('nama')); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="input-1">sippmi</label>
                                                        <input type="text" class="form-control" id="input-1" placeholder="Masukkan SIPPMI" required name="sippmi" value="<?php echo e(old('sippmi')); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="input-1">Alamat</label>
                                                        <textarea type="text" class="form-control" id="input-1" rows="4" placeholder="Masukkan Alamat" required name="alamat" value="<?php echo e(old('alamat')); ?>"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="input-1">Telp Kantor</label>
                                                        <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nomor Telepon Kantor" required name="telp_kantor" value="<?php echo e(old('telp_kantor')); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="input-1">Fax (opt)</label>
                                                        <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nomor Fax" name="telp_kantor2" value="<?php echo e(old('telp_kantor2')); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="input-1">Email</label>
                                                        <input type="email" class="form-control" id="input-1" placeholder="Masukkan Email" required name="surel" value="<?php echo e(old('surel')); ?>">
                                                    </div>
                                                    <br>
                                                    <div class="form-group">
                                                     <button type="submit" class="btn btn-primary px-5"><i class="icon-check"></i> Simpan</button>
                                                   </div>
                                                </form>
                                            </div>
                                            
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->

                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Export</h4>
                                <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead class="text-center">
                                            <tr>
                                                <th>Nama</th>
                                                <th>SIPPMI</th>
                                                <th>Alamat</th>
                                                <th>Telepon</th>
                                                <th>Fax</th>
                                                <th>Email</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a href="<?php echo e(route('company.show', $a->uuid)); ?>"><?php echo e($a->nama); ?></a> </td>
                                                <td><?php echo e($a->sippmi); ?></td>
                                                <td><?php echo e($a->alamat); ?></td>
                                                <td><?php echo e($a->telp_kantor); ?></td>
                                                <td><?php echo e($a->telp_kantor2); ?></td>
                                                <td><?php echo e($a->surel); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/company/index.blade.php ENDPATH**/ ?>