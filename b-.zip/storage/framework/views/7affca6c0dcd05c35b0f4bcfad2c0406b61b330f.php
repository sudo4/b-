 <?php $__env->startSection('content'); ?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Users</h1>
    </div>
    <a class="btn btn-sm btn-primary" href="<?php echo e(route('users.index')); ?>">Back</a>
    <h2><?php echo e($title); ?></h2>
    <form method="post" action="<?php echo e(route('users.store')); ?>" data-parsley-validate class="form-horizontal form-label-left">

        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?> row">
            <label for="name" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-10">
                <input type="text" value="<?php echo e(Request::old('name') ?: ''); ?>" id="name" name="name" class="form-control col-md-7 col-xs-12"> <?php if($errors->has('name')): ?>
                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> row">
            <label for="email" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input type="text" value="<?php echo e(Request::old('email') ?: ''); ?>" id="email" name="email" class="form-control col-md-7 col-xs-12"> <?php if($errors->has('email')): ?>
                <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> row">
            <label for="password" class="col-sm-2 col-form-label">Password</label>
            <div class="col-sm-10">
                <input type="password" value="<?php echo e(Request::old('password') ?: ''); ?>" id="password" name="password" class="form-control col-md-7 col-xs-12"> <?php if($errors->has('password')): ?>
                <span class="help-block"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('confirm_password') ? ' has-error' : ''); ?> row">
            <label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
            <div class="col-sm-10">
                <input type="password" value="<?php echo e(Request::old('confirm_password') ?: ''); ?>" id="confirm_password" name="confirm_password"
                    class="form-control col-md-7 col-xs-12"> <?php if($errors->has('confirm_password')): ?>
                <span class="help-block"><?php echo e($errors->first('confirm_password')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('role_id') ? ' has-error' : ''); ?> row">
            <label class="col-sm-2 col-form-label" for="category_id">Role
                <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control" id="role_id" name="role_id">
                    <?php if(count($roles)): ?> <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                </select>
                <?php if($errors->has('role_id')): ?>
                <span class="help-block"><?php echo e($errors->first('role_id')); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="ln_solid"></div>

        <div class="form-group">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <button type="submit" class="btn btn-success">Create User</button>
            </div>
        </div>
    </form>
</main>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminpages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/admin/users/users_create.blade.php ENDPATH**/ ?>