

<?php $__env->startSection('content'); ?>
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Datatable</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Datatable</li>
                            </ol>
                            <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content bg-secondary">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('visitor.store')); ?>", method="post">
			                                        <?php echo csrf_field(); ?>
			                                        <div class="form-group">
			                                          <label for="input-1">Nama</label>
			                                          <input type="text" class="form-control" id="input-1" placeholder="Masukkan Nama" required name="nama" value="<?php echo e(old('nama')); ?>">
			                                        </div>
			                                        <div class="form-group">
			                                            <label for="input-1">NIK</label>
			                                            <input type="number" class="form-control" id="input-1" placeholder="Masukkan NIK" required name="nik" value="<?php echo e(old('nik')); ?>">
			                                        </div>
			                                        <div class="form-group">
			                                            <label for="input-1">No Handphone</label>
			                                            <input type="number" class="form-control" id="input-1" placeholder="Masukkan No Handphone" required name="phone" value="<?php echo e(old('phone')); ?>">
			                                        </div>
			                                        <h4 class="form-header text-uppercase">
			                                        </h4>
			                                        <br>
			                                        <div class="form-group">
			                                         <button type="submit" class="btn btn-primary icheck-material-primary"> 
			                                          <input id="primary1" type="radio" name="konfirmasi" value="tidak_hadir" checked="tidak_hadir" style="opacity: 0%">
			                                          Simpan
			                                          <input id="primary1" type="radio" name="konfirmasi" style="opacity: 0%">
			                                      	</button>
			                                          
			                                       </div>
			                                   </form>
                                            </div>
                                            
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->

                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Data Export</h4>
                                <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                         <thead>
                                    <tr class="text-center">
                                        <th>Nama</th>
                                        <th>Nik</th>
                                        <th>No Handphone</th>
                                        <th>Konfirmasi Kehadiran</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                	<tbody>
		                                    <?php $__currentLoopData = $visitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                    <tr>
		                                        <td> <a href="<?php echo e(route('visitor.edit', $a->uuid)); ?>"><?php echo e($a->nama); ?></a></td>
		                                        <td><?php echo e($a->nik); ?></td>
		                                        <td><?php echo e($a->phone); ?></td>
		                                        <td class="text-center">
		                                          <?php if($a->konfirmasi == 'hadir'): ?>                                                
		                                          <strong class="text-success">HADIR</strong>
		                                          <?php elseif($a->konfirmasi == 'tidak_hadir'): ?>
		                                          <strong class="text-warning">BELUM DIKONFIRMASI</strong>
		                                          <?php endif; ?>
		                                        </td>
		                                        <td class="text-center">
		                                            <a type="button" class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
		                                                <span class="caret"></span>
		                                            </a>
		                                            <div class="dropdown-menu">
		                                              <?php if (app('laratrust')->hasRole('superadministrator')) : ?>
		                                              <a href="<?php echo e(route('visitor.edit', $a->uuid)); ?>" class="dropdown-item">Edit</a>
		                                              <?php endif; // app('laratrust')->hasRole ?>
		                                              <a href="<?php echo e(route('visitor.show', $a->uuid)); ?>" class="dropdown-item">Konfirmasi</a>
		                                              <div class="dropdown-divider"></div>
		                                              
		                                            </div>
		                                        </td>
		                                    </tr>
		                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/visitor/index.blade.php ENDPATH**/ ?>