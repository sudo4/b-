

<?php $__env->startSection('content'); ?>
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
               <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor"></h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li></li>
                                <li></li>
                            </ol>
                            
                        </div>
                    </div>
                </div>
                 <div class="row justify-content-center">
                    <!-- Column -->
                    <div class="col-lg-4">
                        <div class="card"> <img class="card-img"  height="456" alt="Card image">
                            <div class="card-img-overlay card-inverse text-white social-profile d-flex justify-content-center">
                                <div class="align-self-center"> <img src="/assets/images/icon/staff.png" class="img-circle" width="100">
                                    <h4 class="card-title"></h4>
                                    <h4 class="card-title"><?php echo e($visitor->nama); ?></h4>
                                    <h6 class="card-subtitle"><?php echo e($visitor->nik); ?></h6>
                                    <h6 class="card-subtitle"><?php echo e($visitor->uuid); ?></h6>
                                    <div class="text-white">
                                    	<form id="personal-info" action="<?php echo e(route('visitor.update', $visitor->uuid)); ?>" method="post">
			                                <?php echo csrf_field(); ?>
			                                <?php echo method_field('patch'); ?>
			                                <button type="submit" href="/visitor" class="btn btn-block btn-outline-warning icheck-material-primary"> 
			                                    <input id="success1" type="radio" name="konfirmasi" value="tidak_hadir" checked="tidak_hadir" style="opacity: 0%">
			                                    CANCEL
			                                    <input id="success1" type="radio" name="konfirmasi" style="opacity: 0%"> 
			                                </button>
			                            </form>
			                            <br>
			                            <form id="personal-info" action="<?php echo e(route('visitor.update', $visitor->uuid)); ?>" method="post">
			                                <?php echo csrf_field(); ?>
			                                <?php echo method_field('patch'); ?>
			                                <button type="submit" href="/visitor" class="btn btn-block btn-outline-success icheck-material-warning"> 
			                                    <input id="success1" type="radio" name="konfirmasi" value="hadir" checked="hadir" style="opacity: 0%">
			                                    CONFIRM
			                                    <input id="success1" type="radio" name="konfirmasi" style="opacity: 0%"> 
			                                </button>
			                            </form>
			                            <br>
			                            <?php if (app('laratrust')->hasRole('superadministrator')) : ?>
					                    
					         
					                          <button class="btn btn-block btn-outline-info icheck-material-primary" data-toggle="modal" data-target="#smallsizemodal">QRCODE</button>
					                          <!-- Modal -->
					                            <div class="modal fade" id="smallsizemodal">
					                              <div class="modal-dialog modal-sm">
					                                <div class="modal-content text-center" style="background: white;">
					                                  <div class="modal-header">
					                                    <div class="modal-body">
					                                    <h3 class="text-secondary"><?php echo e($visitor->nama); ?></h3>
					                                    <hr>
					                                      <?php echo QrCode::size(220)->generate(Request::url());; ?>

					                                    </div>
					                                  </div>
					                                </div>
					                              </div>
					                            </div>
					                 
					                    <?php endif; // app('laratrust')->hasRole ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>   
            </div>
                

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\apjati\Desktop\b-\resources\views/visitor/show.blade.php ENDPATH**/ ?>